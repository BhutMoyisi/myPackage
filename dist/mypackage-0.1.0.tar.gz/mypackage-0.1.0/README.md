# mypackage
This library is part of an initial demonstration, that taught me how to publish my own Python package, as part of the ALX Data Science course.

# How to install
Follow these instructions...